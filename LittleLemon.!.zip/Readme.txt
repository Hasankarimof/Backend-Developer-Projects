
/api/menu/
/api/bookings/
/api/auth/login/
/api/auth/logout/
/api/auth/registration/
    